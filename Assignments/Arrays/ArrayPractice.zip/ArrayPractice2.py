userWords = input("Let me tell you how many words you wrote: ").split()
userWordsNumber = str(len(userWords))
print("You used " + userWordsNumber + " words!")
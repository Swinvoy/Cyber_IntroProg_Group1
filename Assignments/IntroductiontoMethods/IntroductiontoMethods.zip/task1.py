def helloWorld():
    print("Hello World")

helloWorld()
helloWorld()

def helloUser(userName):
    print("Hello " + userName)


var = input("What is your name? ")
helloUser("bob")
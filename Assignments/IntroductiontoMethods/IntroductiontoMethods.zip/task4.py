def addItAllUp(total):
    count = 0
    for x in range(total+1):
        count += x   
    print(count)

addItAllUp(int(input("Add all these numbers up! ")))
addItAllUp(55)